console.log("hello how r u");

function slideshow() {
  var img = document.getElementById("ssss");
  var slides = [
    "https://img.tttcdn.com/advertising/2021/9/17/7k4SRh58571292.jpg",
    "https://img.tttcdn.com/advertising/2021/9/15/mKF7to-597358888.jpg",
    "https://img.tttcdn.com/advertising/2021/9/2/GTWLz41854528948.jpg",
    "https://img.tttcdn.com/advertising/2021/9/1/b8Ac6w-1842757343.jpg",
  ];

  img.style.width = "100%";
  img.style.height = "500px";

  img.src = slides[0];

  var i = 1;

  setInterval(function () {
    img.textContent = "";
    img.src = slides[i];

    i++;

    if (i == 3) {
      i = 0;
    }
  }, 2000);
}
slideshow();

var but = document.getElementById("ww");

//but.addEventListener("click", display);

function cal(b) {
  var a = { name: "wow" };
  var b = fetch(`http://localhost:1234/user/pp/${a}`);
}

function login() {
  window.location.href = "/user/sign";
}

function putname() {
  var dd = document.getElementById("loginame");

  if (localStorage.getItem("session") == null) {


    dd.innerHTML = "login";
  } else {
    
    var ss=JSON.parse(localStorage.getItem('session'))


     
    dd.innerHTML = ss.name;
  }
}

putname();

function cart() {
  window.location.href = "/user/cart";
}
