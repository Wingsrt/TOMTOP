


async function pop(){
 
    var pop=document.getElementById('pop');
  
    pop.style.visibility='visible'

    var body=document.querySelector('body');

    body.style.backgroundColor="rgba(40, 0, 0, 0.1)"
    


} 


async function submit(){
  
     var mob=document.getElementById('mob').value;
     var add=document.getElementById('add').value;
     var cot=document.getElementById('cot').value;

     
     var a={
         mob:mob,
         add:add,
         cot:cot


     }


      localStorage.setItem('addd',JSON.stringify(a))

      var pop=document.getElementById('pop');
  
      pop.style.visibility='hidden'


      var dd=document.getElementById('dd');

      dd.style.background='white'

      dd.style.visibility='visible'
      

      var mobb=document.createElement('label');
      var addd=document.createElement('label');
      var cott=document.createElement('label');


      var q=JSON.parse(localStorage.getItem("addd"));

    
      mobb.innerHTML=q.mob;
      mobb.style.color='gray'
       
       addd.innerHTML=q.add;
       addd.style.color='gray'

       cott.innerHTML=q.cot;
       cott.style.color='gray'



      dd.append(mobb,addd,cott)
      var body=document.querySelector('body');

      body.style.backgroundColor="white"

    
}