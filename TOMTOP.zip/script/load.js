var qqq=0;


function th(){
  
  console.log("wow")
}

async function load() {
  var div = document.getElementById("div");

  var a = JSON.parse(localStorage.getItem("cart"));

  var t = 0;

  var ii = 0;
  a.forEach((el) => {
    var b = document.createElement("div");
    b.style.marginLeft = "20px";
    b.style.display = "flex";
    b.style.background = "transparent";
    b.style.borderBottom = "0.5px solid #999";

    var j = document.createElement("img");

    j.src =
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAw1BMVEX///8hISEAAABkvGoXFxdouWpmumrj8+fW1tZgtV9iYmIeHh6GxIUaGhpiuWaf0J3S59MQEBAKCgrp6en4+Pjw8PCCgoLe3t67u7vm5uYzMzPJyck8PDywsLBqamosLCyNjY2ZmZlOTk55eXmfn59WVlZERESnp6fOzs42NjaIiIjY2NjDw8NlZWVISEhycnL/+v/6//mu2rXK5MfY+N+GwY+p06Z4vn7x//Rxtnllsm1Yu2OW0KTw9O2Hw4h3tX7F38ybVoVmAAAMCklEQVR4nO2daXfaOBSGwTEpxTGNjQlbCNCwJSSky0zThGln/v+vGmzJRMav7zVNkNpz9JzTL64XvUa+upudSsVisVgsFovFYrFYLBaLxWKxWCwWi8VisZjn87vzcrz7XPlkerCH8+n7l6fn0/dlOH1++vL9z5IY/yRfnzbvm6e1E57aafP95ul8e8xn0wMvzXakX5uxvGas4JRhu9dWZO1r5Y9S+FetuVUW/0A8yU04adb++oMUVip/b9IfiEfuufnb9KAP4Xw7R2Oa5ZD7npse9gF829Ti36929qEMj7VYY23zzfSwD+AsfgpPN/98L7X393/eJwbn7Mijeksek8ew+a7cIvfpXTJPN49HHtVbkig8OflRcvcfibn5fRR+/nb28+fPsyLi/zsVBvLxsXAvlcdHYXZP2T2/aVlPfvzbjJewQsMY/59cAUqaUmlMT4vPKaltnso92a/jS3PD+mKl18LDDqhtmjrs7dnzc7wUFLooqj9W3qcRMHs2n5912NsPW4eTczWPxcnpBw0Kz2ub5wPm31vyvKlp8Xv+eyoV9R2Dp/90CIxjd1P8ScGHxTTtugnaGhV2HRN0NSocOFX9OAONCutGFNY1KuyFBhSGPY0K20YU6rQ0FddLLuq7OvCTa3muToGVaqLQnzV0MHMThVWtCi8ThU5Hy8U6iV3zLrVcLGWWzBxN9lusTf5My8VSHpKJo2kN7iYK3QctF0sZB4l1W2i52CJRGIy1XGx30WS5CCf721vskfyiljvHJLmYo+d2pgzFbb3YG4rjBEPyuGngBFP6zIHj7N24i2TCOPSZ3xr5aFxlNk4cr+qRA1kke1A/xjDZIyvxSudDn7IU5u2jui0axUuIS5m8ZBklF7Zk7fNGkbrtozDcy9cM+GDkEjVSt7XE+PtR0UGVinDYneIdon5yDi/zLPZ1Lr4pbSfvSLVHYnSE+8gqbHvJOUaZcwgX0dHqlsKxRjfsSHiF4s7dZOYBe9RRQPd1Lp4XYsVgx9oSz/dc3YbmiwZuwLMhLQLxvLAKO8CCyWf+5nUDPpgZsG8Nl3NWWYXCBXUb6ralCbd0t0bdqdt4Z5VViFzQO7T2Hh/pZ3Tz2yhnlVUovMHgVt3Whf7T0RmHeTWTAmf1BVYhOoX0gcevGu/hTMO8vy9iAGoorMIxcLJlHEO7s2+PdL2v1W38dGIVosl/LR5vvY737vFvgG2ESWAVIgPWANs0sAILF2/WWYVoEZLL7Op1Az6YHnA++IwRqxBluOZim858cEwrzDuQwuWigiNWochSZhw/6e6GfPrgbWlX80FAxAoou4N632TIUtUcWlSiZD55bmbugPFl4RSie9RLnHzvkgg7jwNys30ufOIUijCi6qvbkDOuBWnDMxUvNhjnFEpb1Ve31cG6pIWHIL9KsQkVTiFK/4hVNtCbD465Bik+tF5n4BQinwF5T1qQrnfGW2QTm5xClIadmHG8cZwz4cInTiFKpd+K26Y34x3TBZOnKNe/g1M4ATHZNXDGtbAsfmSKgwtOIZrm8uHWmw+OqQM3G+b6VTiFKA8inXGdjRiCTnK7/bnqarDBBacQhBaRyFEGejPeMS3gmLLBBacQhBbRCOT5tSCuXA1UhS1QzcjAKRzlQ4t2IM6p3S3d5YTzwQURPnEKPXHOTGhhJh8cM8+73pEIGoPC+80ojEStIFSP74BQWxPIKoyYYJVRKMPq0UHW63igyqxIOISFdo9R2BEKM78XuwIdD5ThFr9rWLg6MwrRGiu9Q90Z7xiUnr5iajOMwgH4vfhE+tEYgi6XCxA0qjAK74DXNzbRiCGQD0jG9b5lhsMolDctE69cm2jEEMhus0x2gZtSjEJ0OF+UPBorsFAtwI+gwii8BcZL5oN1Z7xjpIvmqdu4HjtGIQotQI5YFyi3KY3hfdExjMJ7MCPZHOwRAddeMQ4Io3CWr8HwefQj4ufnT4/J3jLDldlINY8unwW/6JCjcpm3AeItheIMPK1QVAqybx1IN0dvB3QKqFymrW1FeX1aYVs0tVXVWYEqsdoAazEaowqtEN0f5FdoA/hTkVi9gqJqJq2wJ8L5TOoH+YbamAIPhGn8ohWiKtMEpNa1gbKjqCKlQCtEVSYjHdApXbC8M7UZWiGqy9ybc7xxKQxVpBRohajKZKQDOqUHsmBM/xKtEPVZ3ZhpxBC0QXYUDVKBVohuz8hIB7REZkc9YNyLsiq0QmBVIpBB1YfMHbrABSlaoGmF18BJEi/mmch4x4iccCZ3iGpuCrRCUEcT+UUj+eCYWX5EdTGiovCJVihzkepiKu+YiXxwzEM+YO0EHnXPaYXJnPAydbQBkzQ4MqAZtOV71HNDKpR1NF99rg11QKcA6x6J8KCoNkMrDERgoh7LrD7HBl2eXr9IhWh9NdQBnYK8rEsyNUYqbIEKMuMFHhuUWVuTDb2kQpnGWqvbUPZNIyizNiOHRCocgJUBZN900gM3nX5vhlSI0snrfPZNJz3hUmU6oVFi/gVSIegjk9k315TCtD9ZNSt01oFUCLIiqKVFJ/IOZ/JOQ7L6RCoEmS2Zm9LfAZ0C8k6ooe8FUiFo0TPWAZ0C8k53ZG2GVHifD56MdUCngLwTSt68QCoEKRlDrx6+AN65Qr3oL5AKQR/80GTGOwZUpaVzGeADSIVB3qU12IghQEVtUsSh/2msAzoFGU6yZkspRLVQYx3QKajDB9RNX6AUoloo14F0dFCXFvkFKUohar8FmRu9dIKiQRWk4SmFqAlROk36O6BTWuK1skxOmKzNUArB2ifywZ5rotVEHUHWrKB3lXdQCkHSCWXVNQOyMuilkB2UQvA6CsrcaAaYFVQZ3kEpBHGXkU/RZQEfpiNrM5RCUJcx8im6LKATmuxaphQeei49AK+K7DynFIJlhmt11MC06NkpqFxQCsHbDeD0ugFNveQbIJRC8IYK13KsAZAAJC08pRCsPFq/P4kBxi7yiQ8EEArlJwx8dXXX+g1RDIjoxTflqj5McRIKe76Y3apCI5+iyyK/EBCq29bE+4KEQvk+YyaBLr7HbKgRQwKGTL3zSShEkZjJ/uC9MYDgAoZPxJBBj4PRDuiUUb5lico8EEMGGZGeecd7VxtSpyTVTUgoBP5sHdS2tAPy1PKzAzC4IBSCxCGdP9cEmJKUM0koBC4uXQPRBPgwHdWZTSgEXeOGPkWXBcS7KMWYQigEiUOjHdApoLCwIupFhEJZx1Ir9oY+RZcFGAOq5kcoBLVIYMb0U8/LkdV9WLctVogq9h9NfRFDRS7KarxL1d6LFaKeAEOfosvSzgcX8r0ZH6VxixXKlr/M+zJ9kx3QKW0QDRKNX8UKe/nEYRoxmlUoo0EPPD5ocnEKsw+0ODX1BXQNROt81+us+L2ZYoX1fMuX7MZdm1WI2jGu8itbSrHCVd5PMN6IIQCd0Inb5sPJRawWfX/faTPcAZ2CGkCv4z+SdngEvCXjzBr7FF0W2MS7XAx/oY4/XGTviuEO6L1hlEy8i7Wl5GvLMp4y63gfOpX4v1GiYLgDOkXmhNclc5rjICw77ZZrL2fETCCsfNV35tNS/mO0KrO8RavxyBF/2s1YB3RKJ/0rer4TNoZv4yTXx3Mn9OR5iz/JpImelw4lFunPFq/tmxhc3IShvzun55kNLWL3+GU0sZl0nJtJ/Vf9rNbw3nECTznh9uxmHe8tk77jqkPaOqlO9WHROVBl1OteXDr7p3Kd0fgooz6IqNt4eWp2I3NuGpNByQnWWi6u5qET+JmTbCe9c3Vn2O1OaU1Ge5MrVhk67qgx6VJzNlp1J/f97f1w946u+qEzXxifoCr1i35OZCwz2Hqb4fzqdrLoDuqdXmtLr1MfdBeTcfy7bf/T9XKH+WE4n5q2oXmiARSZjNgNwnDvzxeHgevDnbe/6Ow3lCeIluO+E/po3OXYWinnfmiuUa8UvcXMj6feweL8wHEvx4PfxLTQRMtJYwSsRyH+1ipVP17cmV7cD6K9WlyvhSEhf7nEFM0fpsvffGoWEHWGk/tRalhc3/c98c/dmp5kc/V+PPxlF+j3oV2/G05vHxqz9TxhPWs83E6Hd1r/4L3FYrFYLBaLxWKxWCwWi8VisVgsFotx/gdDBwW+b7AsoAAAAABJRU5ErkJggg==";

    j.style.width = "40px";
    j.style.height = "40px";
    j.addEventListener("click", function () {
      splice(ii, el);
    });
    ii++;

    var c = document.createElement("img");
    c.style.width = "110px";
    c.style.height = "110px";
    var d = document.createElement("p");
    d.style.width = "230px";
    var f = document.createElement("label");
    f.style.width = "30px";
    f.style.marginLeft = "10px";
    f.style.border="2xp solid black"

    var e = document.createElement("label");
    e.style.marginLeft = "400px";

    c.src = el.img;
    d.innerHTML = el.title;
    e.innerHTML = el.price;
    f.innerHTML = el.country;
    t += el.price;

    b.append(c, d, j, f, e);

    div.append(b);
  });

  var amount=document.getElementById('amount')
  var amountt=document.getElementById('amountt')
    
    qqq=t;
  amount.innerHTML=t;
  amountt.innerHTML=t

  var o={
    pri:t
  };

  localStorage.setItem('pp',JSON.stringify(o));
  console.log(t);

}

load();

function splice(ii, o) {
  console.log(o);

  var hh = JSON.parse(localStorage.getItem("cart"));

  for (var i = 0; i < hh.length; i++) {
    if (hh[i].title == o.title) {
      hh.splice(i, 1);

      localStorage.setItem("cart", JSON.stringify(hh));

      break;
    }
  }

  window.location.reload();

  /*
  var hh=JSON.parse(localStorage.getItem('cart'))

  hh.forEach(function(el){

     
    if(hh.title==)



  })*/
}



function wd(){

  window.location.href="/user/check"
}


function www(){
 
var amount=document.getElementById('amount')
var amountt=document.getElementById('amountt')

var e=JSON.parse(localStorage.getItem('pp'))

amount.innerHTML=e.pri
amountt.innerHTML=e.pri


}

www()



