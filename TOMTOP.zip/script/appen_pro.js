async function append(){

   var a=await fetch(`http://localhost:1234/user/getpro`);

   a=await a.json();
   console.log(a);


var z=document.getElementById("menulow")


 


  a.forEach(el=> {

   var div=document.createElement('div');



   div.classList="productdiv"


   div.addEventListener('click',function(){

          localStorage.setItem('item',JSON.stringify(el))
     redirect(el);
        

   })


       var img=document.createElement('img');
    var h4=document.createElement('h4');
    h4.classList="title"

    var h45=document.createElement('h4');
    h45.classList="price"


      
    h4.innerHTML=el.title;
    h45.innerHTML=`USD-${el.price}`;
    img.src=el.img;
    img.classList='proimg'


div.append(img,h4,h45);

z.append(div)
 
  });




}


append()



async function redirect(){


console.log("hello")

window.location.href="/user/showpro"


}


async function show(){
 
     var a=document.getElementById("product_img");
     var c=document.getElementById("ttitle");
     var e=document.getElementById("pricetag");


     
    var b= JSON.parse(localStorage.getItem('item'));

     

   


     a.src=b.img;


     c.innerHTML=b.title;
     e.innerHTML=`PRICE:-${b.price}`;


}

show()



async function store(){


    let arr;
    ss=JSON.parse(localStorage.getItem('item'));

    arr=localStorage.getItem('cart');

    if(arr==null){
      arr=[];
    }
    else{
      arr=JSON.parse(localStorage.getItem('cart'));
    }

    arr.push(ss)

    localStorage.setItem('cart',JSON.stringify(arr))
   


}


function ww(){

  window.location.href="/user/cart"
}



/*
 <div id="productdiv">
        <img class="proimg" src="" alt="preview image" height="100" />
        <h4 id="title"></h4>
        <h4 id="price"></h4>
      </div>*/