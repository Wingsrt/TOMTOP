function register() {
  window.location.href = "/user/register";
}

async function call() {
  var a = document.getElementById("name").value;
  var b = document.getElementById("password").value;

  //console.log(a, b);

  var c = await fetch(`http://localhost:1234/user/login`);

  c = await c.json()


  console.log(b)

  c.forEach((el) => {
    if (el.password ==b) {
       
      localStorage.setItem("session",JSON.stringify(el))
    }
  });

  if (localStorage.getItem('session') != null){
    alert ('yes');
   // localStorage.removeItem('session');
    window.location.href="/user/"
  } else {
    alert ('no');
  }
}
