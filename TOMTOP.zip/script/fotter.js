function wow(){
 window.location.href='/user/thanks'
}


