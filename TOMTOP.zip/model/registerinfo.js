const mongoose = require("mongoose");

const infoo = new mongoose.Schema({
  name: { type: String },
  passwordconfirm:{type:String},
  password: { type:String},
});

const info= mongoose.model("info", infoo);

module.exports = info;
