const mongoose = require("mongoose");

const menuitem = new mongoose.Schema({
  title: { type: String },
  price: { type: Number },
  img: { type: String },
  country:{type:String}

  
});

const menu = mongoose.model("menu", menuitem);

module.exports = menu;
