const { application } = require("express");
const express = require("express");
const router = express.Router();
const menu = require("../model/model.js");
const info = require("../model/registerinfo.js");

router.post("/menu", async function (req, res) {
  const b = await menu.create(req.body);

  return res.send(b);
});


router.get('/thanks',async function(req,res){


  return res.render('thanks');

})

router.get("/pro", async function (req, res) {
  console.log("wow");
  return res.render("product");
});

//-------sign----////

router.get("/sign", async function (req, res) {
  return res.render("sign");
});

router.get("/login", async function (req, res) {
  const f = await info.find().lean().exec();

  return res.send(f);
});

//------register---///
router.get("/register", async function (req, res) {
  return res.render("register");
});

//-----register form----///

router.post("/registerform", async function (req, res) {
  const s = await info.create(req.body);

  console.log(s);
});

router.get("/", async function (req, res) {
  const ite = await menu.find().lean().exec();
  return res.render("index", {});
});

//------------get product--////
router.get("/getpro", async function (req, res) {
  const ite = await menu.find().lean().exec();

  return res.send(ite);
});

//----------show product by click--/////

router.get("/showpro", async function (req, res) {
  return res.render("showpro", {});
});

//--------cart-------///

router.get("/cart", async function (req, res) {
  return res.render("cart", {});
});

router.get("/pp/:id", async function (req, res) {
  var ss = await req.params.id;

  console.log(ss);
});


//-----------checkout---//

router.get("/check",async function(req,res){

  return res.render('check',{})

})

module.exports = router;
