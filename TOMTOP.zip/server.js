const express = require("express");
const path = require("path");
const mongoose = require("mongoose");
const connect = require("./db/db.js");

const app = express();

const st = path.join(__dirname, "./assest");
const sss = path.join(__dirname, "./script");
app.use(express.static(sss));

app.use(express.static(st));

const ss = require("./controller/controller.js");

app.use(express.json());

app.use(express.urlencoded({ extended: false }));

app.set("views", path.join(__dirname, "views"));

app.set("view engine", "ejs");

app.use("/user", ss);

app.listen(1234, async function () {
  await connect();
  console.log("hello i am shanant");
});
 